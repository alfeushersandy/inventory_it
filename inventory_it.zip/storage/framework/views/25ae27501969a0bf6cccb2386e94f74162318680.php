<?php echo e($slot); ?>

<?php /**PATH G:\project\inventory_it\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>