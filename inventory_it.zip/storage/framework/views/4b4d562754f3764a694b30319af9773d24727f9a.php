<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-12">
                <h2 class="content-title"><?php echo e($item->nama_kategori); ?></h2>
            </div>
            <?php
                $total  = DB::table('master_barang')->where('kategori_id', $item->id_kategori)->count();
                $tersedia = DB::table('master_barang')->where('kategori_id', $item->id_kategori)->where('status', 'Tersedia')->count();
                $digunakan = DB::table('master_barang')->where('kategori_id', $item->id_kategori)->where('status', 'Digunakan')->count();
                $onservice = DB::table('master_barang')->where('kategori_id', $item->id_kategori)->where('status', 'Onservice')->count();
                $rusak = DB::table('master_barang')->where('kategori_id', $item->id_kategori)->where('status', 'Rusak')->count();
            ?>

            <div class="row">
                <div class="col-12 col-md-6 col-lg-2">
                    <div class="statistics-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex flex-column justify-content-between align-items-start">
                                <h5 class="content-desc">Total</h5>
                                <h3 class="statistics-value"><?php echo e($total); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-2">
                    <div class="statistics-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex flex-column justify-content-between align-items-start">
                                <h5 class="content-desc">Tersedia</h5>
                                <h3 class="statistics-value"><?php echo e($tersedia); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-2">
                    <div class="statistics-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex flex-column justify-content-between align-items-start">
                                <h5 class="content-desc">Digunakan</h5>
                                <h3 class="statistics-value"><?php echo e($digunakan); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-2">
                    <div class="statistics-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex flex-column justify-content-between align-items-start">
                                <h5 class="content-desc">On Service</h5>
                                <h3 class="statistics-value"><?php echo e($onservice); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-2">
                    <div class="statistics-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="d-flex flex-column justify-content-between align-items-start">
                                <h5 class="content-desc">Rusak</h5>
                                <h3 class="statistics-value"><?php echo e($rusak); ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory_it\resources\views/dashboard/index.blade.php ENDPATH**/ ?>