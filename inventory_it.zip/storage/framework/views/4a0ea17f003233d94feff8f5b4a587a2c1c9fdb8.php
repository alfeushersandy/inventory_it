

<?php $__env->startSection('title'); ?>
    Detail Barang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="accordion" id="accordionExample">
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Detail Barang
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
        <div class="accordion-body">
          <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <table>
                        <tr>
                            <td><b>Kode Barang</b></td>
                            <td>:</td>
                            <td><?php echo e($barang->kode_barang); ?></td>
                        </tr>
                        <tr>
                            <td>Kode Barang Lama</td>
                            <td>:</td>
                            <td><?php echo e($barang->kode_barang_lama); ?></td>
                        </tr>
                        <tr>
                            <td>Kategori</td>
                            <td>:</td>
                            <td><?php echo e($barang->kategori[0]->nama_kategori); ?></td>
                        </tr>
                        <tr>
                            <td>Lokasi</td>
                            <td>:</td>
                            <td><?php echo e($barang->lokasi[0]->nama_lokasi); ?></td>
                        </tr>
                        <tr>
                            <td>Departemen</td>
                            <td>:</td>
                            <td><?php echo e($barang->lokasi[0]->departemen); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <table>
                        <tr>
                            <td>Merk</td>
                            <td>:</td>
                            <td><?php echo e($barang->merek); ?></td>
                        </tr>
                        <tr>
                            <td>Tipe</td>
                            <td>:</td>
                            <td><?php echo e($barang->tipe); ?></td>
                        </tr>
                        <tr>
                            <td>User</td>
                            <td>:</td>
                            <td><?php echo e($barang->user); ?></td>
                        </tr>
                        <tr>
                            <td>Status</td>
                            <td>:</td>
                            <td><?php echo e($barang->status); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          History Service
        </button>
      </h2>
      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
            <div class="box-body table-responsive mt-4">
                <table class="table table-striped table-bordered" style="text-align: center;">
                    <thead class="thead-dark">
                        <th>Kode Serah</th>
                        <th>Lokasi</th>
                        <th>Barang</th>
                        <th>PIC</th>
                        <th>Tanggal Service</th>
                        <th>Tanggal Selesai</th>
                        <th>Biaya</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->serah[0]->kode_serah); ?></td>
                            <td><?php echo e($item->lokasi[0]->nama_lokasi); ?></td>
                            <td><?php echo e($item->barang[0]->tipe); ?></td>
                            <td><?php echo e($item->pic); ?></td>
                            <td><?php echo e(tanggal_indonesia($item->tanggal_service, false)); ?></td>
                            <?php if($item->tanggal_selesai_service): ?>
                                <td><?php echo e(tanggal_indonesia($item->tanggal_selesai_service, false)); ?></td>
                            <?php else: ?>
                                <td><?php echo e($item->tanggal_selesai_service); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($item->biaya); ?></td>
                            <td><?php echo e($item->ket); ?></td>
                            <td><?php echo e($item->status); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                    </tbody>
                </table>
            </div>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingThree">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          History Transfer Barang
        </button>
      </h2>
      <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
        <div class="accordion-body">
            <div class="box-body table-responsive mt-4">
                <table class="table table-striped table-bordered" style="text-align: center;">
                    <thead class="thead-dark">
                        <th>Kode Serah</th>
                        <th>Merek</th>
                        <th>Tipe</th>
                        <th>User</th>
                        <th>Lokasi</th>
                        <th>Tanggal Serah</th>
                        <th>Tanggal Kembali</th>
                        <th>Status</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mutasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mutasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($mutasi->serah_id); ?></td>
                                    <td><?php echo e($mutasi->barang[0]->merek); ?></td>
                                    <td><?php echo e($mutasi->barang[0]->tipe); ?></td>
                                    <td><?php echo e($mutasi->user); ?></td>
                                    <td><?php echo e($mutasi->lokasi_tujuan_id); ?></td>
                                    <td><?php echo e($mutasi->tanggal_serah); ?></td>
                                    <td><?php echo e($mutasi->tanggal_kembali); ?></td>
                                    <?php if($mutasi->status == 0): ?>
                                        <td>Sudah Kembali</td>
                                    <?php else: ?>
                                        <td>Belum Kembali</td>
                                    <?php endif; ?>
                                    
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory_it\resources\views/master_barang/detail.blade.php ENDPATH**/ ?>