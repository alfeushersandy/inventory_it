<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cetak Barcode</title>

    <style>
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>
    <table width="100%">
        <tr>
            <?php $__currentLoopData = $databarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="text-center">
                    
                    <div class="row" style="margin-top: 25px; margin-bottom: -25px">
                        <img src="<?php echo e(asset('assets/images/logo_ahg.png')); ?>" alt="" style="height:90px; width:90px;">
                        <img src="data:image/png;base64, <?php echo e(base64_encode(QrCode::format('svg')->size(80)->errorCorrection('H')->generate(env('APP_URL') . '/barang/show?kode_barang=' .$barang->kode_barang))); ?>" style="margin-left:20px">
                    </div>
                    <br>
                    <hr>
                    <?php echo e($barang->kode_barang); ?>

                </td>
                <?php if($no++ % 3 == 0): ?>
                    </tr><tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                </tr><tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                </tr><tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                </tr><tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                </tr><tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                </tr><tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
    </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\inventory_it\resources\views/master_barang/qrcode.blade.php ENDPATH**/ ?>