


<?php $__env->startSection('title'); ?>
    Maintenance Barang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="row">
        <div class="col-lg-12">
            <div class="box">
                <div class="box-header with-border">
                    <a href="<?php echo e(route('maintenance.form')); ?>" class="btn btn-success btn-xs btn-flat"><i class="fa fa-plus-circle"></i> Tambah</a>
                </div>
                <div class="box-body table-responsive mt-4">
                    <table class="table table-striped table-bordered" style="text-align: center;">
                        <thead class="thead-dark">
                            <th>No</th>
                            <th>Kode Serah</th>
                            <th>Lokasi</th>
                            <th>Barang</th>
                            <th>PIC</th>
                            <th>Tanggal Service</th>
                            <th>Tanggal Selesai</th>
                            <th>Biaya</th>
                            <th>Keterangan</th>
                            <th>Status</th>
                            <th width="15%"><i class="fa fa-cog"></i></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $maintenance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <?php if($item->serah_id): ?>
                                        <td><?php echo e($item->serah[0]->nomor_serah); ?></td>
                                    <?php else: ?>
                                        <td></td>
                                    <?php endif; ?>
                                    <td><?php echo e($item->lokasi[0]->nama_lokasi); ?></td>
                                    <td><?php echo e($item->barang[0]->tipe); ?></td>
                                    <td><?php echo e($item->pic); ?></td>
                                    <td><?php echo e(tanggal_indonesia($item->tanggal_service, false)); ?></td>
                                    <?php if($item->tanggal_selesai_service): ?>
                                        <td><?php echo e(tanggal_indonesia($item->tanggal_selesai_service, false)); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($item->tanggal_selesai_service); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($item->biaya); ?></td>
                                    <td><?php echo e($item->ket); ?></td>
                                    <td><?php echo e($item->status); ?></td>
                                    <td>
                                        <?php if($item->status == 'Submited'): ?>
                                            <button onclick="showPic('<?php echo e(route('maintenance.service', $item->id_maintenance)); ?>')" class="btn btn-primary">Proses</button>
                                        <?php elseif($item->status == "On Service"): ?>
                                            <button onclick="selesai('<?php echo e(route('maintenance.selesai', $item->id_maintenance)); ?>')" class="btn btn-success">Selesai</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('maintenance.pic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('maintenance.selesai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    let table;
    $(function(){
        table = $('.table').DataTable();
    })

    function addForm(url) {
        $('#modal-form').modal('show');
        $('#modal-form .modal-title').text('Tambah Master Barang');
    
        $('#modal-form form')[0].reset();
        $('#modal-form form').attr('action', url);
        $('#modal-form [name=_method]').val('post');
    }

    function showPic(url) {
        $('#modal-pic').modal('show');
        $('#modal-pic .modal-title').text('Pelaksana');

        $('#modal-pic form')[0].reset();
        $('#modal-pic form').attr('action', url);
    }

    function selesai(url) {
        $('#modal-selesai').modal('show');
        $('#modal-selesai .modal-title').text('Service Selesai');

        $('#modal-selesai form')[0].reset();
        $('#modal-selesai form').attr('action', url);
    }

    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory_it\resources\views/maintenance/index.blade.php ENDPATH**/ ?>