<div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        History Transfer Barang
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
      <div class="accordion-body">
          <div class="box-body table-responsive mt-4">
              <table class="table table-striped table-bordered" style="text-align: center;">
                  <thead class="thead-dark">
                      <th>No</th>
                      <th>Kode Serah</th>
                      <th>Lokasi</th>
                      <th>Barang</th>
                      <th>PIC</th>
                      <th>Tanggal Service</th>
                      <th>Tanggal Selesai</th>
                      <th>Biaya</th>
                      <th>Keterangan</th>
                      <th>Status</th>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($item->serah_id); ?></td>
                          <td><?php echo e($item->lokasi[0]->nama_lokasi); ?></td>
                          <td><?php echo e($item->barang[0]->tipe); ?></td>
                          <td><?php echo e($item->pic); ?></td>
                          <td><?php echo e(tanggal_indonesia($item->tanggal_service, false)); ?></td>
                          <?php if($item->tanggal_selesai_service): ?>
                              <td><?php echo e(tanggal_indonesia($item->tanggal_selesai_service, false)); ?></td>
                          <?php else: ?>
                              <td><?php echo e($item->tanggal_selesai_service); ?></td>
                          <?php endif; ?>
                          <td><?php echo e($item->biaya); ?></td>
                          <td><?php echo e($item->ket); ?></td>
                          <td><?php echo e($item->status); ?></td>
                          <td>
                              <?php if($item->status == 'Submited'): ?>
                                  <button onclick="showPic('<?php echo e(route('maintenance.service', $item->id_maintenance)); ?>')" class="btn btn-primary">Proses</button>
                              <?php elseif($item->status == "On Service"): ?>
                                  <button onclick="selesai('<?php echo e(route('maintenance.selesai', $item->id_maintenance)); ?>')" class="btn btn-success">Selesai</button>
                              <?php endif; ?>
                          </td>
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                  </tbody>
              </table>
          </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\inventory_it\resources\views/master_barang/detail2.blade.php ENDPATH**/ ?>