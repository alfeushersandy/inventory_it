<div class="modal fade" id="modal-barang" tabindex="-1" role="dialog" aria-labelledby="modal-form">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Pilih Aset</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered table-barang">
                    <thead>
                        <th width="5%">No</th>
                        <th>Kode barang</th>
                        <th>Kategori</th>
                        <th>Merek</th>
                        <th>Tipe</th>
                        <th>Status</th>
                        <th><i class="fa fa-cog"></i></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="5%"><?php echo e($key+1); ?></td>
                                <td><span class="label label-success"><?php echo e($item->kode_barang); ?></span></td>
                                <td><?php echo e($item->nama_kategori); ?></td>
                                <td><?php echo e($item->merek); ?></td>
                                <td><?php echo e($item->tipe); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('detail.store', $item->id_barang)); ?>" class="btn btn-primary btn-xs btn-flat">
                                        Pilih
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH G:\project\inventory_it\resources\views/serah_detail/barang.blade.php ENDPATH**/ ?>