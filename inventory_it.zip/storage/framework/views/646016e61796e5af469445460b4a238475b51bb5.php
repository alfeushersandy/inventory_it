


<?php $__env->startSection('title'); ?>
    Barang Kembali
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="row">
        <div class="col-lg-12">
            <div class="box">
                <div class="box-body table-responsive mt-4">
                    <table class="table table-striped table-bordered" style="text-align: center;">
                        <thead class="thead-dark">
                            <th>No</th>
                            <th>Nomor Serah</th>
                            <th>Kode Barang</th>
                            <th>Merek</th>
                            <th>Tipe</th>
                            <th>User</th>
                            <th>Tanggal Serah</th>
                            <th>Status</th>
                            <th width="15%"><i class="fa fa-cog"></i></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo e($barang->serah[0]->nomor_serah); ?></td>
                                    <td><?php echo e($barang->barang[0]->kode_barang); ?></td>
                                    <td><?php echo e($barang->barang[0]->merek); ?></td>
                                    <td><?php echo e($barang->barang[0]->tipe); ?></td>
                                    <td><?php echo e($barang->barang[0]->user); ?></td>
                                    <td><?php echo e($barang->tanggal_serah); ?></td>
                                    <td><?php echo e($barang->status); ?></td>
                                    <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('kembali.selesai', $barang->id_serah_detail)); ?>">Selesai</a>
                                            <a class="btn btn-warning mt-2" href="<?php echo e(route('kembali.rusak', $barang->id_serah_detail)); ?>"> Rusak </a>
                                    </td>
                                </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        let table;
        $(function(){
            table = $('.table').DataTable();
        })
        function addFormKembali(url) {
            $('#modalkembali').modal('show');
            $('#modalkembali .modal-title').text('Pengembalian Barang');
            $('#modalkembali form').attr('action', url);
        }

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\project\inventory_it\resources\views/kembali/index.blade.php ENDPATH**/ ?>